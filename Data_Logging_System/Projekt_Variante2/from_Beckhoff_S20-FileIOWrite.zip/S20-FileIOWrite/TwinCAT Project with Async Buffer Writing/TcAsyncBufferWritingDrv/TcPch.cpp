// TcPch.cpp : source file that includes just the standard includes
//  TcPch.pch will be the pre-compiled header
//  TcPch.obj will contain the pre-compiled type information

#include "TcPch.h"
#pragma hdrstop
#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#include <statreg.cpp>
#endif
#ifdef WIN32_RUNTIME
#include <atlimpl.cpp>
#endif
