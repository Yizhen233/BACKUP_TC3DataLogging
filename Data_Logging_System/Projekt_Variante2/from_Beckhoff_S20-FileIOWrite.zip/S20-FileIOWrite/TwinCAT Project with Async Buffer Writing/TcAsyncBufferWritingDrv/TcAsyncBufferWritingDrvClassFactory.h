///////////////////////////////////////////////////////////////////////////////
// TcAsyncBufferWritingDrv.h

#pragma once

#include "ObjClassFactory.h"

class CTcAsyncBufferWritingDrvClassFactory : public CObjClassFactory
{
public:
	CTcAsyncBufferWritingDrvClassFactory();
	DECLARE_CLASS_MAP()
};


